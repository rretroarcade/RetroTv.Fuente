# encoding=utf8
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import xbmcgui
import xbmcplugin
import xbmc
import urllib
import urllib2
import urlparse
import xbmcaddon
import os
import re
import unicodedata
from datetime import datetime
from lib import youtube_dl
from types import UnicodeType

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')
sys.path.append(xbmc.translatePath(os.path.join(PATH, 'lib')))

def safe_unicode(value):
    if type(value) is UnicodeType:
        return value
    else:
        try:
            return unicode(value, 'utf-8')
        except:
            return unicode(value, 'iso-8859-1')
 
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def download_video_url(page_url, local_path, title):
    videos = get_video_url(page_url)
    request_video = urllib2.Request(videos[-1][1])
    response = urllib2.urlopen(request_video)
    CHUNK = 16 * 1024
    with open(local_path, 'ab') as f:
        while True:
            chunk = response.read(CHUNK)
            if not chunk:
                break
            f.write(chunk)
    f.close()
    xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % ('Descarga Finalizada', title, 4000, PATH + '/icon.png'))

def get_video_url(page_url):
    video_urls = []
    
    ydl = youtube_dl.YoutubeDL({'outtmpl': u'%(id)s%(ext)s'})
    result = ydl.extract_info(page_url, download=False)

    for entries in result["formats"]:

        if entries["ext"] != "rtmp":
            video_url = safe_unicode(entries['url']).encode('utf-8')

            if entries["ext"] != "mp4":
                title = safe_unicode(entries["format"]).encode('utf-8')

            elif entries["ext"] == "mp4":

                if entries.has_key("vbr"):
                    title = "mp4-" + safe_unicode(str(entries["vbr"])).encode('utf-8') + " " + safe_unicode(entries["format"]).encode('utf-8').rsplit("-",1)[1]
                else:
                    title = safe_unicode(entries["format"]).encode('utf-8')

            try:
                calidad = int(safe_unicode(str(entries["vbr"])))
            except:
                try:
                    calidad = int(title.split("-")[1].strip())
                except:
                    calidad = 3000

            video_urls.append(["%s" % title, video_url, 0, False, calidad])
            
    video_urls.sort(key=lambda video_urls: video_urls[4], reverse=True)

    return video_urls

def strip_accents(text):
    try:
        text = unicode(text.encode("utf-8"), 'utf-8')
    except NameError:
        pass
    text = unicodedata.normalize('NFD', text)\
           .encode('ascii', 'ignore')\
           .decode("utf-8")
    return str(text)

def only_legal_chars(string_in):
    string_out = strip_accents(string_in)
    string_out = re.sub(r'[\\/:"*?<>|]+', "", string_out)
    string_out = "".join(i for i in string_out if ord(i)<128)
    string_out = ' '.join(string_out.split())
    return string_out

def time_to_seconds(time_in):
    a = time_in.split(':')

    if len(a) > 1:
        if len(a) == 2:
            return (int(a[0])*60) + int(a[1])
        else:
            return (int(a[0])*60*60) + (int(a[1])*60) + int(a[2])

    else:
        return ''

def con_puto_cero(n_in):
    if(n_in < 10):
        return '0' + str(n_in)
    else:
        return str(n_in)

def super_tres(title, href):

    href = href.replace('alacarta', 'super3').replace('/videos', '') + 'videos'

    request = urllib2.Request('https://www.ccma.cat' + href)
    html_show = urllib2.urlopen(request).read()
    
    a = html_show.split('Pàgina 1 de ')
    if len(a) > 1:
        b = a[1].split('</p>')
        total_pages = int(b[0])
    else:
        total_pages = 1

    if total_pages > 1:

        a = html_show.split('/Comu/standalone/tv3_super3_item_fitxa-programa_videos/contenidor/contenidorVideosStandAlone/2/')
        b = a[1].split("'")

        z = b[0].split('" ')
        if len(z) > 1:
            id_programa = z[0]
        else:
            id_programa = b[0]

        for x in range(1, total_pages + 1):
            request = urllib2.Request('https://www.ccma.cat/Comu/standalone/tv3_super3_item_fitxa-programa_videos/contenidor/contenidorVideosStandAlone/' + str(x) + '/' + id_programa)
            episodes_html = urllib2.urlopen(request).read()

            c = episodes_html.split('<article')

            for y in range(1, len(c)):

                d = c[y].split('href="')
                e = d[1].split('"')

                super_href = e[0]

                f = c[y].split('src="')
                g = f[1].split('"')

                super_image = g[0]

                h = c[y].split('</h2>')
                i = h[0].split('>')

                super_title = i[-1]

                commands = []

                cmd = 'XBMC.RunPlugin({})'.format(build_url({'mode': 'download', 'title': title + ' - ' + super_title, 'href': super_href}))
                commands.append(( 'Descargar', cmd ))

                url = build_url({'mode': 'episode', 'title': super_title, 'href': super_href})
                li = xbmcgui.ListItem(super_title, iconImage = super_image)
                li.setInfo(type="Video", infoLabels = {
                    "plot": "[B]" + title + "\n\n[/B]" + super_title, 
                    "Title" : super_title
                })
                li.setArt({'fanart': super_image})
                li.addContextMenuItems(commands)
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    else:

        c = html_show.split('<article')

        for y in range(1, len(c)):

            d = c[y].split('href="')
            e = d[1].split('"')

            super_href = e[0]

            f = c[y].split('src="')
            g = f[1].split('"')

            super_image = g[0]

            h = c[y].split('</h2>')
            i = h[0].split('>')

            super_title = i[-1]

            commands = []

            cmd = 'XBMC.RunPlugin({})'.format(build_url({'mode': 'download', 'title': title + ' - ' + super_title, 'href': super_href}))
            commands.append(( 'Descargar', cmd ))

            url = build_url({'mode': 'episode', 'title': super_title, 'href': super_href})
            li = xbmcgui.ListItem(super_title, iconImage = super_image)
            li.setInfo(type="Video", infoLabels = {
                "plot": "[B]" + title + "\n\n[/B]" + super_title, 
                "Title" : super_title
            })
            li.setArt({'fanart': super_image})
            li.addContextMenuItems(commands)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

mode = args.get('mode', None)

if mode is None:

    request = urllib2.Request('https://www.ccma.cat/tv3/alacarta/programes/')
    index_html = urllib2.urlopen(request).read()

    a = index_html.split('<li class="F-abcTema')

    for x in range(1, len(a)):
        b = a[x].split('href="')
        c = b[1].split('"')

        d = a[x].split('role="button">')
        e = d[1].split('</a>')

        url = build_url({'mode': 'indice', 'title': e[0], 'href': c[0]})
        li = xbmcgui.ListItem(e[0], iconImage = PATH + '/icon.png')
        li.setInfo(type="Video", infoLabels={"plot": e[0]})
        li.setArt({'fanart': PATH + '/fanart.jpg'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'indice':

    request = urllib2.Request('https://www.ccma.cat' + args['href'][0])
    index_html = urllib2.urlopen(request).read()

    a = index_html.split('<a href="/tv3/alacarta/')

    for x in range(1, len(a)):
        b = a[x].split('">')
        c = b[1].split('</a>')

        c[0] = c[0].strip()

        url = build_url({'mode': 'show', 'title': c[0], 'href': '/tv3/alacarta/' + b[0]})
        li = xbmcgui.ListItem(c[0], iconImage = PATH + '/icon.png')
        li.setInfo(type="Video", infoLabels={"plot": c[0]})
        li.setArt({'fanart': PATH + '/fanart.jpg'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'show':

    dia = con_puto_cero(int(datetime.now().day))
    mes = con_puto_cero(int(datetime.now().month))
    ano = con_puto_cero(int(datetime.now().year))

    is_super_tres = 0

    if 'page' not in args:

        request = urllib2.Request('https://www.ccma.cat' + args['href'][0])
        html_show = urllib2.urlopen(request).read()

        a = html_show.split('<input type="hidden" name="programa_id" value="')
        if len(a) > 1:
            b = a[1].split('"')
            programa_id = b[0]

            c = args['href'][0].split('fitxa-programa')
            if len(c) > 1:
                request = urllib2.Request('https://www.ccma.cat' + args['href'][0].replace('/fitxa-programa', '/cercador/fitxa-programa') + '?text=&dataInici=01%2F01%2F1800&dataFi=' + dia + '%2F' + mes + '%2F' + ano + '&data_publicacio=01%2F01%2F1800-' + dia + '%2F' + mes + '%2F' + ano + '&profile=videos&items_pagina=50&ordre=-data_publicacio&programa_id=' + programa_id)
            else:
                request = urllib2.Request('https://www.ccma.cat' + args['href'][0] + 'cercador/?text=&dataInici=01%2F01%2F1800&dataFi=' + dia + '%2F' + mes + '%2F' + ano + '&data_publicacio=01%2F01%2F1800-' + dia + '%2F' + mes + '%2F' + ano + '&profile=videos&items_pagina=50&ordre=-data_publicacio&programa_id=' + programa_id)

        else:
            is_super_tres = 1

    else:
        c = args['href'][0].split('fitxa-programa')
        if len(c) > 1:
            request = urllib2.Request('https://www.ccma.cat' + args['href'][0].replace('/fitxa-programa', '/cercador/fitxa-programa') + 'cercador/?text=&dataInici=01%2F01%2F1800&dataFi=' + dia + '%2F' + mes + '%2F' + ano + '&data_publicacio=01%2F01%2F1800-' + dia + '%2F' + mes + '%2F' + ano + '&profile=videos&items_pagina=50&ordre=-data_publicacio&programa_id=' + args['programa_id'][0] + '&pagina=' + args['page'][0])
        else:
            request = urllib2.Request('https://www.ccma.cat' + args['href'][0] + 'cercador/?text=&dataInici=01%2F01%2F1800&dataFi=' + dia + '%2F' + mes + '%2F' + ano + '&data_publicacio=01%2F01%2F1800-' + dia + '%2F' + mes + '%2F' + ano + '&profile=videos&items_pagina=50&ordre=-data_publicacio&programa_id=' + args['programa_id'][0] + '&pagina=' + args['page'][0])

    if is_super_tres == 1:
        super_tres(args['title'][0], args['href'][0])
    else:
    
        html_show = urllib2.urlopen(request).read()

        a = html_show.split('trobat <strong>')
        if len(a) > 1:
            b = a[1].split('</strong>')

            if float(b[0]) % 50.0 > 0:
                total_pages = (int(b[0]) / 50) + 1
            else:
                total_pages = int(b[0]) / 50

            a = html_show.split('<li class="F-llistat-item">')

            for x in range(1, len(a)):
                b = a[x].split('<h3 class="titol"><a href="')
                c = b[1].split('">')

                d = c[1].split('</a>')

                e = a[x].split('src="')
                if len(e) > 1:
                    f = e[1].split('"')
                    item_image = 'https:' + f[0]
                    item_fanart = 'https:' + f[0]
                else:
                    item_image = PATH + '/icon.png'
                    item_fanart = PATH + '/fanart.jpg'

                g = a[x].split(':</span>')
                if len(e) > 1:
                    h = g[1].split('</time>')
                    duration = time_to_seconds(h[0].strip())
                else:
                    duration = ''

                i = a[x].split('<p class="entradeta">')
                j = i[1].split('</p>')

                commands = []

                cmd = 'XBMC.RunPlugin({})'.format(build_url({'mode': 'download', 'title': args['title'][0] + ' - ' + d[0], 'href': c[0]}))
                commands.append(( 'Descargar', cmd ))

                url = build_url({'mode': 'episode', 'title': d[0], 'href': c[0]})
                li = xbmcgui.ListItem(d[0], iconImage = item_image)
                li.setInfo(type="Video", infoLabels = {
                    "plot": "[B]" + args['title'][0] + "\n\n[/B]" + d[0] + "\n\n" + j[0].strip(), 
                    "Title" : d[0], 
                    "Duration" : duration
                })
                li.setArt({'fanart': item_fanart})
                li.addContextMenuItems(commands)
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

            if 'page' in args:
                if int(args['page'][0]) < total_pages:
                    url = build_url({
                        'mode': 'show', 
                        'href': args['href'][0], 
                        'programa_id': args['programa_id'][0], 
                        'title': args['title'][0], 
                        'page': str(int(args['page'][0]) + 1)
                    })
                    li = xbmcgui.ListItem(str(int(args['page'][0]) + 1) + ' >> ', iconImage = PATH + '/icon.png')
                    li.setInfo(type="Video", infoLabels={"plot": str(int(args['page'][0]) + 1) + ' >> '})
                    li.setArt({'fanart': PATH + '/fanart.jpg'})
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            else:
                if total_pages > 1:
                    url = build_url({
                        'mode': 'show', 
                        'href': args['href'][0], 
                        'programa_id': programa_id, 
                        'title': args['title'][0], 
                        'page': '2'
                    })
                    li = xbmcgui.ListItem('2 >> ', iconImage = PATH + '/icon.png')
                    li.setInfo(type="Video", infoLabels={"plot": '2 >> '})
                    li.setArt({'fanart': PATH + '/fanart.jpg'})
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'episode':
    videos = get_video_url('https://www.ccma.cat' + args['href'][0])
    listitem = xbmcgui.ListItem(args['title'][0])
    listitem.setInfo('video', {'Title': args['title'][0]})
    xbmc.Player().play(videos[-1][1], listitem)

elif mode[0] == 'download':
    dialog = xbmcgui.Dialog().browse(0, 'Elige un directorio para descargar el video', "video")
    if dialog != '':
        download_video_url('https://www.ccma.cat' + args['href'][0], dialog + only_legal_chars(args['title'][0]) + '.mp4', args['title'][0])