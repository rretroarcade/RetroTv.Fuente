#pragma once

void Log(unsigned int loglevel, const char *format, ...);
