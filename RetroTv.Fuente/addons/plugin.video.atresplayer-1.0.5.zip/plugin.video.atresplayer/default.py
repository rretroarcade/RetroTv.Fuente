# encoding=utf8
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import xbmcgui
import xbmcplugin
import xbmc
import urllib
import urllib2
import urlparse
import json
import xbmcaddon
import os
from lib import youtube_dl
 
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')
sys.path.append(xbmc.translatePath(os.path.join(PATH, 'lib')))
 
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def get_video_url(page_url):
    if my_addon.getSetting('username') == '' or my_addon.getSetting('password') == '':
        return 'no user pass'
    else:
        ydl = youtube_dl.YoutubeDL({'outtmpl': u'%(id)s%(ext)s', 'username':my_addon.getSetting('username'), 'password':my_addon.getSetting('password')})
        result = ydl.extract_info(page_url, download=False)
        if 'entries' in result:
            video = result['entries'][0]
        else:
            video = result
        return video

mode = args.get('mode', None)

if mode is None:

    request = urllib2.Request('https://www.atresplayer.com/')
    index_html = urllib2.urlopen(request).read()

    sections = []

    a = index_html.split('SiteNavigationElement","name":"')

    for x in range(1, len(a)):
        b = a[x].split('"')
        c = a[x].split(',"url":"')
        d = c[1].split('"')
        sections.append({'name': b[0], 'url': d[0].replace('\\u002F', '/')})

    for item in sections:
        url = build_url({'mode': 'indice', 'title': item['name'], 'href': item['url']})
        li = xbmcgui.ListItem(item['name'], iconImage = PATH + '/icon.png')
        li.setInfo(type="Video", infoLabels={"plot": item['name']})
        li.setArt({'fanart': PATH + '/fanart.jpg'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'indice':

    request = urllib2.Request(args['href'][0])
    cat_html = urllib2.urlopen(request).read()

    a = cat_html.split('"redirect":false,"href":"')
    b = a[1].split('"')
    c = b[0].split('channel\u002F')
    d = c[1].split('?')
    cha_id = d[0]
    e = b[0].split('categoryId=')
    cat_id = e[1]

    request = urllib2.Request('https://api.atresplayer.com/client/v1/row/search?entityType=ATPFormat&sectionCategory=true&mainChannelId=' + cha_id + '&categoryId=' + cat_id + '&sortType=AZ&size=100&page=0')
    cat_json = json.loads(urllib2.urlopen(request).read())

    shows = []

    for item in cat_json['itemRows']:
        shows.append({
            "id" : item['formatId'],
            "title" : item['title'],
            "image" : item['image']['pathHorizontal'],
            "href" : item['link']['url']
        })

    total_pages = int(cat_json['pageInfo']['totalPages'])

    if total_pages > 0:
        for x in range(1, total_pages):
            request = urllib2.Request('https://api.atresplayer.com/client/v1/row/search?entityType=ATPFormat&sectionCategory=true&mainChannelId=' + cha_id + '&categoryId=' + cat_id + '&sortType=AZ&size=100&page=' + str(x))
            cat_json = json.loads(urllib2.urlopen(request).read())
            for item in cat_json['itemRows']:
                shows.append({
                    "id" : item['formatId'],
                    "title" : item['title'],
                    "image" : item['image']['pathHorizontal'],
                    "href" : item['link']['url']
                })

    shows = sorted(shows, key = lambda i: i['title'],reverse=False)
    for item in shows:
        url = build_url({'mode': 'show', 'title': item['title'], 'href': item['href'], 'id': item['id']})
        li = xbmcgui.ListItem(item['title'], iconImage = item['image'])
        li.setInfo(type="Video", infoLabels={"plot": item['title']})
        li.setArt({'fanart': item['image']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'show':

    request = urllib2.Request('https://api.atresplayer.com/client/v1/row/search?entityType=ATPEpisode&formatId=' + args['id'][0] + '&size=100&page=0')
    show_data = urllib2.urlopen(request).read()
    show_json = json.loads(show_data)

    episodes = []

    for item in show_json['itemRows']:
        tag = ''
        if 'tagType' in item:
            tag = '[P]'
        episodes.append({
            "title" : item['title'],
            "subtitle" : item['subTitle'],
            "image" : item['image']['pathHorizontal'],
            "href" : item['link']['url'],
            "type" : tag
        })

    total_pages = int(show_json['pageInfo']['totalPages'])

    if total_pages > 0:
        for x in range(1, total_pages):
            request = urllib2.Request('https://api.atresplayer.com/client/v1/row/search?entityType=ATPEpisode&formatId=' + args['id'][0] + '&size=100&page=' + str(x))
            show_json = json.loads(urllib2.urlopen(request).read())
            for item in show_json['itemRows']:
                tag = ''
                if 'tagType' in item:
                    tag = '[P]'
                episodes.append({
                    "title" : item['title'],
                    "subtitle" : item['subTitle'],
                    "image" : item['image']['pathHorizontal'],
                    "href" : item['link']['url'],
                    "type" : tag
                })

    for item in episodes:
        url = build_url({'mode': 'episode', 'title': item['title'], 'href': item['href']})
        li = xbmcgui.ListItem(item['title'], iconImage = item['image'])
        li.setInfo(type="Video", infoLabels={"plot": item['title']})
        li.setArt({'fanart': item['image']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'episode':

    videos = get_video_url('https://www.atresplayer.com' + args['href'][0])

    if videos == 'no user pass':

        xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % ('Identifícate', 'Debes introducir tu usuario y password', 4000, PATH + '/icon.png'))

    else:
        dumped = json.dumps(videos)

        a = dumped.split('.m3u8')

        final_videos = []

        for x in range(0, len(a)):
            b = ''
            c = ''
            b = a[x].split('"')
            if (x+1) < len(a):
                c = a[x+1].split('"')

            if c != '':
                final_videos.append(b[len(b)-1] + '.m3u8')

        b = a[len(a)-2].split('"')
        c = a[len(a)-1].split('"')
        final_video = b[len(b)-1] + '.m3u8'

        listitem = xbmcgui.ListItem(args['title'][0])
        listitem.setInfo('video', {'Title': args['title'][0]})

        xbmc.Player().play(final_video, listitem)