import xbmcaddon
import urllib, os,re,urllib2
import xbmc,xbmcgui
import subprocess
import zipfile
import stat
import shutil
import time
import pwd
import grp
import stat


""" BOTONES GUI"""


addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')


""" DETECTAR SO Y PONER RUTAS"""


line9 = 'NO Soportado'
line10 = 'Solo armv7 o aarch64'
line11 = 'Solo Linux'

if xbmc.getCondVisibility('system.platform.linux') and not xbmc.getCondVisibility('system.platform.Android'):
	if "arm" in os.uname()[4]:
		ruta = xbmc.translatePath("special://home")
		rutaacestream = os.path.join(os.sep, ruta, "userdata", "addon_data", "program.plexus", "acestream")
		rutasystem = os.path.join(os.sep, ruta, "addons", "service.system.acestreammedia")
		rutasystem1 = os.path.join(os.sep, ruta, "addons", "service.system.acestreammedia-1_0_11")
	elif "aarch" in os.uname()[4]:
		ruta = "/storage/.config"
		rutaservice = xbmc.translatePath("special://home")
		rutaacestream = os.path.join(os.sep, ruta, "acestream")
		rutasystem = os.path.join(os.sep, rutaservice, "addons", "service.system.acestreammedia")
		rutasystem1 = os.path.join(os.sep, rutaservice, "addons", "service.system.acestreammedia-1_0_11")
	else :
		xbmcgui.Dialog().ok(addonname, line9, line10)
		exit()
else :
	xbmcgui.Dialog().ok(addonname, line9, line11)
	exit()	


""" PARAR Y ELIMINAR ACESTREAM EN PLEXUS"""

if "arm" in os.uname()[4]:
	if os.path.exists(rutaacestream):
		if os.geteuid() == 0 :
			subprocess.call(["pkill", "acestream"])
			subprocess.call(["umount", "-l", rutaacestream+"/androidfs/proc"])
			subprocess.call(["umount", "-l", rutaacestream+"/androidfs/sys"])
			subprocess.call(["umount", "-l", rutaacestream+"/androidfs/dev"])
			time.sleep(0.1)
			shutil.rmtree(rutaacestream)
		else:
			subprocess.call(["sudo", "pkill", "acestream"])
			subprocess.call(["sudo", "umount", "-l", rutaacestream+"/androidfs/proc"])
			subprocess.call(["sudo", "umount", "-l", rutaacestream+"/androidfs/sys"])
			subprocess.call(["sudo", "umount", "-l", rutaacestream+"/androidfs/dev"])	
			time.sleep(0.1)
			subprocess.call(["sudo", "rm", "-rf", rutaacestream])
	else:
		pass
else:
	if os.path.exists(rutaacestream):
		subprocess.call(["pkill", "acestream"])
		subprocess.call(["umount", "-l", rutaacestream+"/androidfs/proc"])
		subprocess.call(["umount", "-l", rutaacestream+"/androidfs/sys"])
		subprocess.call(["umount", "-l", rutaacestream+"/androidfs/dev"])
		time.sleep(0.1)
		shutil.rmtree(rutaacestream)
	else:
		pass	

	
""" PARAR Y ELIMINAR ACESTREAM EN .CONFIG"""

if "arm" in os.uname()[4]:
	if os.path.exists('/storage/.config/acestream'):
			subprocess.call(["pkill", "acestream"])
			subprocess.call(["umount", "-l", "/storage/.config/acestream/androidfs/proc"])
			subprocess.call(["umount", "-l", "/storage/.config/acestream/androidfs/sys"])
			subprocess.call(["umount", "-l", "/storage/.config/acestream/androidfs/dev"])
			time.sleep(0.1)
			shutil.rmtree('/storage/.config/acestream')
	else:
		pass
	

""" PARAR Y ELIMINAR SERVICE.SYSTEM.ACESTREAM """

if "arm" in os.uname()[4]:
	if os.path.exists(rutasystem):
		if os.geteuid() == 0 :
			subprocess.call(["pkill", "acestream"])
			subprocess.call(["umount", "-l", rutasystem+"/acestream.engine/androidfs/proc"])
			subprocess.call(["umount", "-l", rutasystem+"/acestream.engine/androidfs/sys"])
			subprocess.call(["umount", "-l", rutasystem+"/acestream.engine/androidfs/dev"])
			time.sleep(0.1)
			shutil.rmtree(rutasystem)
		else :
			subprocess.call(["sudo", "pkill", "acestream"])
			subprocess.call(["sudo", "umount", "-l", rutasystem+"/acestream.engine/androidfs/proc"])
			subprocess.call(["sudo", "umount", "-l", rutasystem+"/acestream.engine/androidfs/sys"])
			subprocess.call(["sudo", "umount", "-l", rutasystem+"/acestream.engine/androidfs/dev"])	
			time.sleep(0.1)
			subprocess.call(["sudo", "rm", "-rf", rutasystem])
	else:
		pass
else:
	if os.path.exists(rutasystem):
		subprocess.call(["pkill", "acestream"])
		subprocess.call(["umount", "-l", rutasystem+"/acestream.engine/androidfs/proc"])
		subprocess.call(["umount", "-l", rutasystem+"/acestream.engine/androidfs/sys"])
		subprocess.call(["umount", "-l", rutasystem+"acestream.engine/androidfs/dev"])
		time.sleep(0.1)
		shutil.rmtree(rutasystem)
	else:
		pass

""" PARAR Y ELIMINAR SERVICE.SYSTEM.ACESTREAM-1_0_11 """

if "arm" in os.uname()[4]:
	if os.path.exists(rutasystem1):
		if os.geteuid() == 0 :
			subprocess.call(["pkill", "acestream"])
			subprocess.call(["umount", "-l", rutasystem1+"/acestream.engine/androidfs/proc"])
			subprocess.call(["umount", "-l", rutasystem1+"/acestream.engine/androidfs/sys"])
			subprocess.call(["umount", "-l", rutasystem1+"/acestream.engine/androidfs/dev"])
			time.sleep(0.1)
			shutil.rmtree(rutasystem1)
		else :
			subprocess.call(["sudo", "pkill", "acestream"])
			subprocess.call(["sudo", "umount", "-l", rutasystem1+"/acestream.engine/androidfs/proc"])
			subprocess.call(["sudo", "umount", "-l", rutasystem1+"/acestream.engine/androidfs/sys"])
			subprocess.call(["sudo", "umount", "-l", rutasystem1+"/acestream.engine/androidfs/dev"])	
			time.sleep(0.1)
			subprocess.call(["sudo", "rm", "-rf", rutasystem1])
	else:
		pass
else:
	if os.path.exists(rutasystem1):
		subprocess.call(["pkill", "acestream"])
		subprocess.call(["umount", "-l", rutasystem1+"/acestream.engine/androidfs/proc"])
		subprocess.call(["umount", "-l", rutasystem1+"/acestream.engine/androidfs/sys"])
		subprocess.call(["umount", "-l", rutasystem1+"acestream.engine/androidfs/dev"])
		time.sleep(0.1)
		shutil.rmtree(rutasystem1)
	else:
		pass


		
	
time.sleep(0.1)
os.mkdir(rutaacestream, 0777)


""" INICIO """


line1 = 'Bienvenido a Plexus-Patcher by Canna_76'
line2 = 'Pulse OK para comenzar'
xbmcgui.Dialog().ok(addonname, line1, line2)


""" DESCARGAR ACESTREAM """

def DownloaderClass(url,dest):
	dp = xbmcgui.DialogProgress()
	dp.create("Plexus-Patcher","Descargando Acestream...")
	urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
	try:
        	percent = min((numblocks*blocksize*100)/filesize, 100)
        	print percent
        	dp.update(percent)
    	except:
        	percent = 100
		dp.update(percent)

url = 'http://acestreampi.ddns.net/NoTocar/test/acestream.zip'
"""url = 'http://80.211.105.59/ace/acestream.zip'"""

if "arm" in os.uname()[4]:
		DownloaderClass(url, ruta+"/userdata/acestream.zip")
else:
		DownloaderClass(url, "/storage/.config/acestream.zip")



""" DESCOMPRIMIR """


pDialog = xbmcgui.DialogProgress()
pDialog.create("Plexus-Patcher","Descarga Completa!")
time.sleep(1.5)
pDialog.update(25, "Descomprimiendo Archivos...")

if "arm" in os.uname()[4]:
		zf=zipfile.ZipFile(ruta+'/userdata/acestream.zip', 'r')

		for i in zf.namelist():
			zf.extract(i, path=ruta+'/userdata/addon_data/program.plexus')
else:
	zf=zipfile.ZipFile(ruta+'/acestream.zip', 'r')

	for i in zf.namelist():
		zf.extract(i, path=ruta)
	
pDialog.update(50, "Estableciendo Permisos...")



""" AUTOSTART AMLOGIC OSMC"""

if "arm" in os.uname()[4]:
	if os.geteuid() != 0 :

		rutarclocal = ("/etc/rc.local")
		rutaautostart = os.path.join(os.sep, ruta, "userdata","addon_data", "program.plexus" ,"acestream" ,"autostart_acestream_osmc.sh")       
		file = open(rutaacestream+"/rc.local", "w")
		file.write("#!/bin/sh -e" + os.linesep)
		file.write(rutaautostart+" &" + os.linesep)
		file.write("exit 0" + os.linesep)
		file.close()
		subprocess.call(["sudo", "chmod", "+x", rutaacestream+"/rc.local"])
        	subprocess.call(["sudo", "chown", "root:root", rutaacestream+"/rc.local"])
		subprocess.call(["sudo", "mv", rutaacestream+"/rc.local", rutarclocal])
	else:
		pass
else:
	file = open(ruta+"/autostart.sh", "w")
	file.write("#!/bin/sh" + os.linesep)
	file.write("(" + os.linesep)
	file.write("/storage/.config/acestream/autostart.sh" + os.linesep)
	file.write(")&")
	file.close()
		
	
""" PERMISOS"""


time.sleep(1)
if os.geteuid() == 0 :
	subprocess.call(['chmod', '777', '-R', rutaacestream])
else:
	rutabinario = os.path.join(rutaacestream, "chroot") 
	st = os.stat(rutabinario)
	os.chmod(rutabinario, st.st_mode | stat.S_IEXEC)
	subprocess.call(['sudo', 'chmod', '777', '-R', rutaacestream])

pDialog.update(75, "Limpiando Archivos...")


""" ELIMINAR ARCHIVOS"""


time.sleep(1)

from os import remove

if "arm" in os.uname()[4]:
	remove(ruta+'/userdata/acestream.zip')
	pDialog.update(100, "Acestream Modificado con Exito!, Reiniciando...")
	time.sleep(4)
	os.system('reboot')
else:
	remove(ruta+'/acestream.zip')
	pDialog.update(100, "Acestream Modificado con Exito!, Reiniciando...")
	time.sleep(4)
	os.system('reboot')

